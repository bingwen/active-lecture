//
//  HistoryViewController.m
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#import "HistoryDetialViewController.h"
#import "HistoryViewController.h"
#import "History.h"
@implementation HistoryViewController
@synthesize tvCell;
@synthesize tableView;

//#define ALDEBUG

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"历史记录";
        
       
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle



- (void)viewDidLoad
{
    [super viewDidLoad];
    HistoryDatabase = [[HistoryDAO alloc]init];
    [HistoryDatabase connect];
    

    listData=[[NSMutableArray alloc]initWithArray:[HistoryDatabase selectMetaData]];
    
#ifdef ALDEBUG
    [listData addObject:[History historyWithClassID:1001 LectureName:@"mac" BlackBoard:@"null" Date:@"1-2-1990"]];
    
#endif
    
    
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] init];
    barButtonItem.title = @"返回";
    barButtonItem.tintColor = [UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1];
    self.navigationItem.backBarButtonItem = barButtonItem;
    [barButtonItem release];

    
    UIBarButtonItem* item=[[UIBarButtonItem alloc]initWithTitle:@"删除" style:UIBarButtonItemStylePlain target:self action:@selector(toggleEdit:)];
    [item setTintColor:[UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1]]; 
    
    self.navigationItem.rightBarButtonItem=item;
    [item release];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(update) name:@"saveReady" object:nil];
    UIImage *image = [UIImage imageNamed:@"title.png"];
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];  
    // Do any additional setup after loading the view from its nib.
}
-(void)update{

    [listData release];
    listData=[[NSMutableArray alloc]initWithArray:[HistoryDatabase selectMetaData]];
    [tableView reloadData];
}
-(void)toggleEdit:(id)sender{

    [self.tableView setEditing:!self.tableView.editing animated:YES];
    if (self.tableView.editing) {
    [self.navigationItem.rightBarButtonItem setTitle:@"完成"];
    }
    else{
        
    [self.navigationItem.rightBarButtonItem setTitle:@"删除"];
    }


}
- (void)viewDidUnload
{
    listData = nil;
    [self setTvCell:nil];
    [HistoryDatabase close];
    HistoryDatabase=nil;
    [super viewDidUnload];
   
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self update];

}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
-(void)dealloc{
    [listData release];
    [HistoryDatabase release];
    [tvCell release];
    
    [super dealloc];
}

#pragma mark -
#pragma mark Table View Method
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [listData count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
  
    static NSString *simpleTableID=@"historyID";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:simpleTableID];
    
    if (cell == nil) {
        NSArray *nib=[[NSBundle mainBundle] loadNibNamed:@"historyTableCell" owner:self options:nil];
        if ([nib count] > 0) {
            cell = self.tvCell;
        }
        else{
            NSLog(@"error");
        }
        
        
    }
    NSUInteger row=[indexPath row];
    History* obj = [listData objectAtIndex:row];
    
    UILabel *label1=(UILabel*)[cell viewWithTag:1];
    UILabel *label2=(UILabel*)[cell viewWithTag:2]; 
    
    label1.text = obj.lectureName;
    label2.text = 
    [NSString stringWithFormat:@"课程ID: %d",obj.classID];
    //cell.imageView.image=[UIImage imageNamed:@"MessageEntrySendButton.png"];
    return cell;
}
//select

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   // NSUInteger row= [indexPath row];
  
    

}
-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    History* obj = [listData objectAtIndex:[indexPath row]];
    HistoryDetialViewController *details = [[[HistoryDetialViewController alloc]initWithNibName:@"HistoryDetialViewController" detailInfo:obj]autorelease];
    [self.navigationController pushViewController:details animated:YES];
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{

    NSUInteger row=[indexPath row];
    History* obj = [listData objectAtIndex:row];
    [HistoryDatabase deleteItemByID:obj.classID];//TODO error
    
    [listData removeObjectAtIndex:row];
    [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

 
@end
