//
//  Lecture.m
//  activelecture
//
//  Created by  on 12-6-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Lecture.h"

@implementation Lecture
@synthesize classID = _classID;
@synthesize lectureName = _lectureName;
@synthesize teacherName = _teacherName;
@synthesize introduction = _introduction;
@synthesize blackBoard = _blackBoard;
@synthesize voteID = _voteID;
@synthesize isVoteValid = _isVoteValid;
@synthesize startTime = _startTime;
@synthesize BASEURL = _BASEURL;
@synthesize isActive = _isActive;


static Lecture* sharedinstance=nil; 
- (id)init {
    self = [super init];
    if (self) {
        _BASEURL= @"http://activelecture.sinaapp.com/ios/";
        _teacherName=@"匿名";
        _lectureName=@"匿名";
        _introduction=@"";
        _blackBoard=@"";
        _isActive= NO;
        _voteID=0;
        
    }
    return self;
}
-(id)initWithClassID:(int)classID 
LectureName:(NSString*)lectureName 
TeacherName: (NSString*) teacherName
Info:(NSString*) introduction
StartTime:(NSString*) startTime
{
    self = [super init];
    if (self) {
        _BASEURL= @"http://activelecture.sinaapp.com/ios/";
        _classID = classID;
        _teacherName=teacherName;
        _lectureName=lectureName;
        _introduction=introduction;
        _startTime = startTime;
        _blackBoard=@"";
        _isActive= NO;
        _voteID=0;
        
    }
    return self;                                           
                                               
                                               
}
+(Lecture *)sharedLecure{
    NSCondition* lock=[[NSCondition alloc]init];
    
    [lock lock];
    if (sharedinstance==nil) {
        sharedinstance = [[Lecture alloc]init];
    }
    [lock unlock];
    [lock release];
    return sharedinstance;

}

-(void)reset
{
    _classID = 0;
    _BASEURL= @"http://activelecture.sinaapp.com/ios/";
    _teacherName=@"匿名";
    _lectureName=@"匿名";
    _introduction=@"";
    _blackBoard=@"";
    _isActive = NO;
}
-(void)setCurrentLecture:(Lecture *)lecture
{
    _classID = lecture.classID;
    _teacherName=lecture.teacherName;
    _lectureName=lecture.lectureName;
    _introduction=lecture.introduction;
    _blackBoard=lecture.blackBoard;
    _isActive = NO;

}
-(void)dealloc
{
    [_BASEURL release];
    [_teacherName release];
    [_lectureName release];
    [_blackBoard release];
    [_introduction release];
    [_startTime release];
}
@end
