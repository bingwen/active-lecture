//
//  LectureDAO.m
//  activelecture
//
//  Created by  on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LectureDAO.h"
#import "Lecture.h"
#define DATABASENAME @"lecture.sqlite3"

@implementation LectureDAO
- (id)init {
    self = [super init];
    if (self) {
        database=NULL;
    }
    return self;
}
-(BOOL)connect{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *datafilePath=[[paths objectAtIndex:0] stringByAppendingPathComponent:DATABASENAME];
    
    NSLog(@"%@",datafilePath);
    
    if (sqlite3_open([datafilePath UTF8String], &database)!=SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0,@"Failed to open database");
    }
    const char *createTable = "CREATE TABLE IF NOT EXISTS LECTURE (CLASSID INTEGER PRIMARY KEY, LECTURENAME VARCHAR(30), TEACHERNAME VARCHAR(30), INTRODUCTION VARCHAR(200),STATEDATE VARCHAR(30))";
    char* errormeg;
    if (sqlite3_exec(database, createTable, NULL, NULL, &errormeg)!=SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0,@"Failed to create table");
    }
    
    return YES;
}
-(void)close{
    if (database!=NULL) {
        sqlite3_close(database);
    }
}
-(BOOL)insert:(id)item{
    Lecture* new=(Lecture*)item;
    char *errormsg="";
    char *update = "INSERT OR REPLACE INTO LECTURE VALUES(?,?,?,?,?);";
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(database, update, -1, &stmt, nil)==SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, new.classID);
        sqlite3_bind_text(stmt, 2, [new.lectureName UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 3, [new.teacherName UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 4, [new.introduction UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 5 , [new.startTime UTF8String], -1 ,NULL); }
    if (sqlite3_step(stmt)!= SQLITE_DONE) {
        NSAssert1(0, @"Error insert : %s", errormsg);
         NSLog(@"failed");
        sqlite3_finalize(stmt);
        return NO;
    }
    else{
        NSLog(@"update new one id = %d",new.classID);
        sqlite3_finalize(stmt);
        return YES;
    }
}
-(NSArray *)selectMetaData{
    
    char *errormsg="query error";
    
    char *query = "SELECT CLASSID, LECTURENAME, TEACHERNAME, STATEDATE FROM LECTURE ORDER BY CLASSID;";
    
    
    sqlite3_stmt *stmt;
    NSMutableArray *lectures=[NSMutableArray array];
    
    if (sqlite3_prepare_v2(database, query, -1, &stmt,nil)== SQLITE_OK){
        while (sqlite3_step(stmt)==SQLITE_ROW){
            
            Lecture * item=[[[Lecture alloc]init]autorelease];
            char* tmp=NULL;
            if ((tmp=(char*)sqlite3_column_text(stmt, 0))!=NULL) {
                item.classID = [[NSString stringWithUTF8String:tmp] intValue];
            }
            
            if ((tmp=(char*)sqlite3_column_text(stmt, 1))!=NULL) {
                item.lectureName=[NSString stringWithUTF8String:tmp];
            }
            if ((tmp=(char*)sqlite3_column_text(stmt, 2))!=NULL) {
                item.teacherName=[NSString stringWithUTF8String:tmp];
            }
            if ((tmp=(char*)sqlite3_column_text(stmt, 3))!=NULL) {
                item.startTime=[NSString stringWithUTF8String:tmp];
            }

            [lectures addObject:item];
        }
    }
    else{
        NSAssert1(0, @"Error select : %s", errormsg);
        
    }
    sqlite3_finalize(stmt);
    
    return lectures;
}
-(NSString *)selectDetailLectureByID:(int)classID
{
    char *errormsg="query error";
    
    char *query = "SELECT INTRODUCTION FROM LECTURE WHERE CLASSID = ?";
    
    NSString* detail=nil;
    sqlite3_stmt *stmt;
    
    if (sqlite3_prepare_v2(database, query, -1, &stmt,nil)== SQLITE_OK){
        sqlite3_bind_int(stmt, 1, classID);  
        while(sqlite3_step(stmt)==SQLITE_ROW){
            
            char* tmp=NULL;
            if ((tmp=(char*)sqlite3_column_text(stmt, 0))!=NULL) {
                detail=[NSString stringWithUTF8String:tmp];
                break;
            }
        }
        
    }
    else{
        NSAssert1(0, @"Error select : %s", errormsg);
        
    }       
    
    sqlite3_finalize(stmt);
    
    return detail;
}
-(BOOL)deleteItemByID:(int)ID
{
    char *errormsg="";
    char *update = "DELETE FROM LECTURE WHERE CLASSID = ?;";
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(database, update, -1, &stmt, nil)==SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, ID);
        
    }
    if (sqlite3_step(stmt)!= SQLITE_DONE) {
        NSAssert1(0, @"Error delete : %s", errormsg);
        sqlite3_finalize(stmt);
        return NO;
    }
    else{
        NSLog(@"delele one item id = %d",ID);
        sqlite3_finalize(stmt);
        return YES;
    }
    
}
-(void)dealloc{
    if (database!=NULL) {
        sqlite3_close(database);
    }
    [super dealloc];
}
@end
