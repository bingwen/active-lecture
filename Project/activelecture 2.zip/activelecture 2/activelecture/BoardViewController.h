//
//  BoardViewController.h
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryDAO.h"
@interface BoardViewController : UIViewController
{
    HistoryDAO* historyData;  
}
@property (retain, nonatomic) IBOutlet UITextView *blackBoardContent;
@property (retain, nonatomic) IBOutlet UITextView *noteTextView;
@property (retain, nonatomic) IBOutlet UILabel *nameLabel;
@property (retain, nonatomic) IBOutlet UIControl *fatherVIew;
@property (retain, nonatomic) IBOutlet UIView *historyView;
@property (retain, nonatomic) IBOutlet UIView *boardView;
- (IBAction)changeView:(id)sender;
- (IBAction)backgroudTap:(id)sender;
-(void)reflesh;
-(void)saveData;
@end
