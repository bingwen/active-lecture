//
//  BoardViewController.m
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "BoardViewController.h"
#import "History.h"
#import "SBJson.h"
#import "Lecture.h"
#import "ASIHTTPRequest.h"
#import "SBJsonParser.h"

@implementation BoardViewController
@synthesize blackBoardContent;
@synthesize boardView;
@synthesize noteTextView;
@synthesize nameLabel;
@synthesize fatherVIew;
@synthesize historyView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"小黑板";
        historyData = [[HistoryDAO alloc]init];
        
        [historyData connect];

        // Custom initialization
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    UIBarButtonItem* refleshButton = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(reflesh)];
    [refleshButton setStyle:UIBarButtonItemStylePlain];
    [refleshButton setTintColor:[UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1]];
    [self.navigationItem setRightBarButtonItem:refleshButton];
    [refleshButton release];
    
    [self.fatherVIew addSubview:historyView];
    [self.fatherVIew addSubview:boardView];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveData) name:UIApplicationWillTerminateNotification object:nil];
    
    
      
    NSDateFormatter *formater = [[ NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyyy-MM-dd"];
    NSString * curTime = [formater stringFromDate:[NSDate date]];
    [formater release];
    
    History* hs = [historyData selectDetailHistoryByID:[Lecture sharedLecure].classID Date:curTime];
    if (hs!=nil) {
    self.blackBoardContent.text = hs.blackboard;
    self.noteTextView.text=hs.note;
    }
  
    // Do any additional setup after loading the view from its nib.
}




-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.nameLabel.text = [[Lecture sharedLecure].teacherName stringByAppendingFormat:@" - %@", [Lecture sharedLecure].lectureName];
    [self reflesh];

    
}
-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [self saveData];
}

-(void)saveData{
    
    History* new = [[History alloc]init];
    new.classID = [Lecture sharedLecure].classID;
    new.lectureName = nameLabel.text;
    new.blackboard = blackBoardContent.text;
    new.note = noteTextView.text;
    
    NSDateFormatter *formater = [[ NSDateFormatter alloc] init];
    [formater setDateFormat:@"yyyy-MM-dd"];
    NSString * curTime = [formater stringFromDate:[NSDate date]];
    [formater release];
    NSLog(@"%@",curTime);
    
    new.date = curTime;
    
    
    [historyData insert:new];
    
    
    [new release];
        
    
}

- (void)viewDidUnload
{
    [historyData close];
    [historyData release];

    [self setBlackBoardContent:nil];
   
    [self setHistoryView:nil];
    [self setBoardView:nil];
    [self setFatherVIew:nil];
    [self setNameLabel:nil];
    [self setNoteTextView:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (IBAction)changeView:(id)sender {
    
    [UIView beginAnimations:@"animationID" context:nil];
	[UIView setAnimationDuration:0.5f];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationRepeatAutoreverses:NO];
    
    
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.fatherVIew cache:YES];//oglFlip, fromLeft 
    [self.fatherVIew exchangeSubviewAtIndex:1 withSubviewAtIndex:0];
	[UIView commitAnimations];
    
}

- (IBAction)backgroudTap:(id)sender {
    [noteTextView resignFirstResponder];
}

-(void)reflesh{
        SBJsonParser* parser=[[SBJsonParser alloc]init];
    
   
        NSString *urlString=[[Lecture sharedLecure].BASEURL stringByAppendingString:@"getBlackBoard/"];
        urlString=[urlString stringByAppendingString:[NSString stringWithFormat:@"%d",[Lecture sharedLecure].classID]];
        
        NSURL *url = [NSURL URLWithString:urlString];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        [request setDelegate:self];
        [request setCompletionBlock:^{
            NSDictionary* array=[parser objectWithString:[request responseString]];
            
                            [Lecture sharedLecure].blackBoard = [array objectForKey:@"blackboard"];            
            blackBoardContent.text = [Lecture sharedLecure].blackBoard;
            //UIAlertView* alert=[[[UIAlertView alloc]initWithTitle:@"response" message:lecutre.lectureName delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil]autorelease];
            //[alert show];
           
        }];
        [request setFailedBlock:^{
            NSError *error = [request error];
            NSLog(@"%@",error.description);
            
        }];
        [parser release];
        [request startAsynchronous];


}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [blackBoardContent release];
    [historyView release];
    [boardView release];
    [fatherVIew release];
    [nameLabel release];
    [noteTextView release];
    [super dealloc];
}

@end
