//
//  database.m
//  activelecture
//
//  Created by  on 12-6-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//
#define DATABASENAME @"history.sqlite3"
#import "HistoryDAO.h"
#import "History.h"


@implementation HistoryDAO
- (id)init {
    self = [super init];
    if (self) {
        database=NULL;
    }
    return self;
}
-(BOOL)connect{

    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *datafilePath=[[paths objectAtIndex:0] stringByAppendingPathComponent:DATABASENAME];

    NSLog(@"%@",datafilePath);
    
    if (sqlite3_open([datafilePath UTF8String], &database)!=SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0,@"Failed to open database");
    }
    const char *createTable = "CREATE TABLE IF NOT EXISTS HISTORY (CLASSID INTEGER, LECTURENAME VARCHAR(30), DATE VARCHAR(30),BLACKBOARD VARCHAR(500),NOTE VARCHAR(500),PRIMARY KEY(CLASSID,DATE))";
    char* errormeg;
    if (sqlite3_exec(database, createTable, NULL, NULL, &errormeg)!=SQLITE_OK) {
        sqlite3_close(database);
        NSAssert(0,@"Failed to create table");
    }
    
    return YES;
}
-(void)close{
    if (database!=NULL) {
        sqlite3_close(database);
    }
}
-(BOOL)insert:(id)item{
    History* new=(History*)item;
    char *errormsg="error";
    char *update = "INSERT OR REPLACE INTO HISTORY VALUES(?,?,?,?,?);";
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(database, update, -1, &stmt, nil)==SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, new.classID);
        sqlite3_bind_text(stmt, 2, [new.lectureName UTF8String], -1, NULL);
       
        sqlite3_bind_text(stmt, 3, [new.date UTF8String], -1, NULL);
         sqlite3_bind_text(stmt, 4, [new.blackboard UTF8String], -1, NULL);
        sqlite3_bind_text(stmt, 5, [new.note UTF8String], -1, NULL);
    }
    if (sqlite3_step(stmt)!= SQLITE_DONE) {
        //NSAssert1(0, @"Error insert : %s", errormsg);
        sqlite3_finalize(stmt);
        return NO;
    }
    else{
        NSLog(@"update new one id = %d , date = %@",new.classID, new.date);
        sqlite3_finalize(stmt);
        return YES;
    }
}
-(NSArray *)selectMetaData{
   
    char *errormsg="query error";
    
    char *query = "SELECT DISTINCT CLASSID, LECTURENAME FROM HISTORY ORDER BY CLASSID;";
    
    
    sqlite3_stmt *stmt;
    NSMutableArray *history=[NSMutableArray array];
    
    if (sqlite3_prepare_v2(database, query, -1, &stmt,nil)== SQLITE_OK){
        while (sqlite3_step(stmt)==SQLITE_ROW){
            
            History * item=[[[History alloc]init]autorelease];
            char* tmp=NULL;
            if ((tmp=(char*)sqlite3_column_text(stmt, 0))!=NULL) {
                item.classID = [[NSString stringWithUTF8String:tmp] intValue];
            }

            
            if ((tmp=(char*)sqlite3_column_text(stmt, 1))!=NULL) {
                item.lectureName=[NSString stringWithUTF8String:tmp];
            }
                       
            [history addObject:item];
        }
    }
    else{
        NSAssert1(0, @"Error select : %s", errormsg);

    }
    sqlite3_finalize(stmt);
    
    return history;
}
-(NSArray *)selectDetailHistoryByID:(int)classID
{
    char *errormsg="query error";
    
    char *query = "SELECT ALL BLACKBOARD,NOTE,DATE FROM HISTORY WHERE CLASSID = ? ORDER BY DATE DESC";
    
   
    sqlite3_stmt *stmt;
    NSMutableArray *history=[NSMutableArray array];

    if (sqlite3_prepare_v2(database, query, -1, &stmt,nil)== SQLITE_OK){
        sqlite3_bind_int(stmt, 1, classID);  
        while(sqlite3_step(stmt)==SQLITE_ROW){
          
            History * item=[[[History alloc]init]autorelease];
            
            char* tmp=NULL;
            if ((tmp=(char*)sqlite3_column_text(stmt, 0))!=NULL) {
                item.blackboard =[NSString stringWithUTF8String:tmp];
            }
             
            if ((tmp=(char*)sqlite3_column_text(stmt, 1))!=NULL) {
                item.note=[NSString stringWithUTF8String:tmp];
            }
            if ((tmp=(char*)sqlite3_column_text(stmt, 2))!=NULL) {
                item.date=[NSString stringWithUTF8String:tmp];
            }

            [history addObject:item];
        }

    }
    else{
      //  NSAssert1(0, @"Error select : %s", errormsg);
        
    }       
    
    sqlite3_finalize(stmt);
    
    return history;
}
-(History*) selectDetailHistoryByID:(int)classID Date:(NSString*)date
{
    char *errormsg="query error";
    
    char *query = "SELECT BLACKBOARD,NOTE FROM HISTORY WHERE CLASSID = ? AND DATE = ?";
    
    
    sqlite3_stmt *stmt;
    History * item=nil;

    if (sqlite3_prepare_v2(database, query, -1, &stmt,nil)== SQLITE_OK){
        sqlite3_bind_int(stmt, 1, classID); 
        sqlite3_bind_text(stmt, 2, [date UTF8String], -1, NULL);
        while(sqlite3_step(stmt)==SQLITE_ROW){
            item=[[[History alloc]init]autorelease];

                       
            char* tmp=NULL;
            if ((tmp=(char*)sqlite3_column_text(stmt, 0))!=NULL) {
                item.blackboard =[NSString stringWithUTF8String:tmp];
            }
            
            if ((tmp=(char*)sqlite3_column_text(stmt, 1))!=NULL) {
                item.note=[NSString stringWithUTF8String:tmp];
            }
                       
            break;
        }
        
    }
    else{
        //ç(0, @"Error select : %s", errormsg);
        
    }       
    
    sqlite3_finalize(stmt);
    
    return item;


}

-(BOOL)deleteItemByID:(int)ID
{
    char *errormsg="";
    char *update = "DELETE FROM HISTORY WHERE CLASSID = ?;";
    
    sqlite3_stmt *stmt;
    if (sqlite3_prepare_v2(database, update, -1, &stmt, nil)==SQLITE_OK) {
        sqlite3_bind_int(stmt, 1, ID);
        
    }
    if (sqlite3_step(stmt)!= SQLITE_DONE) {
       // NSAssert1(0, @"Error insert : %s", errormsg);
        sqlite3_finalize(stmt);
        return NO;
       }
    else{
        NSLog(@"delele one item id = %d",ID);
        sqlite3_finalize(stmt);
        return YES;
    }

}
-(void)dealloc{
    if (database!=NULL) {
        sqlite3_close(database);
    }
    [super dealloc];
}
@end
