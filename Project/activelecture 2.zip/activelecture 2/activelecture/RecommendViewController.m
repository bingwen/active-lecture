//
//  LectureListViewController.m
//  activelecture
//
//  Created by  on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "RecommendViewController.h"
#import "LectureInfoViewController.h"
#import "SBJson.h"
#import "ASIHTTPRequest.h"
#import "LectureDAO.h"
#import "Lecture.h"
@implementation RecommendViewController
@synthesize tableView;
@synthesize tvCell;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"推荐课程";
    
    
    UIImage *image = [UIImage imageNamed:@"title.png"];
          
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];    
    
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] init];
    barButtonItem.title = @"推荐";
    barButtonItem.tintColor = [UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1];
    self.navigationItem.backBarButtonItem = barButtonItem;
    [barButtonItem release];
    
    
    
    lectureArray = [[NSMutableArray alloc]init];
    
   
    
    
  
}
-(void)refresh
{
    SBJsonParser* parser = [[SBJsonParser alloc]init];
    Lecture* sharedLecture = [Lecture sharedLecure];
    
    
    NSString *urlString=[sharedLecture.BASEURL stringByAppendingString:@"getSuggest"];
    NSURL *url = [NSURL URLWithString:urlString];
    ASIHTTPRequest *request =[ASIHTTPRequest requestWithURL:url];
       
    [request setDelegate:self];
    [request setCompletionBlock:^{
        NSArray* datas = [parser objectWithString:[request responseString]];
        [lectureArray removeAllObjects];
        for (NSDictionary* item in datas) {
            Lecture* new=[[Lecture alloc]init];
            new.classID = [[item objectForKey:@"id"]intValue];
            new.teacherName = [item objectForKey:@"teacher_name"];
            new.lectureName = [item objectForKey:@"name"];
            new.introduction = [item objectForKey:@"summary"];
            new.startTime = [item objectForKey:@"apply_time"];
            new.isActive = [[item objectForKey:@"state"]boolValue];
            [lectureArray addObject:new];
            [new release];
        }
        [self.tableView reloadData];
        
    }];
    [parser release];
    [request startAsynchronous];
    
}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self refresh];
}
- (void)viewDidUnload
{
    [self setTableView:nil];
    
    [self setTableView:nil];
    [self setTvCell:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [lectureArray count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableID=@"lectureListID";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:simpleTableID];
    
    if (cell == nil) {
        NSArray *nib=[[NSBundle mainBundle] loadNibNamed:@"lectureTableCell" owner:self options:nil];
        if ([nib count] > 0) {
            cell = self.tvCell;
        }
        else{
            NSLog(@"error");
        }
        
        
    }
    NSUInteger row=[indexPath row];
    Lecture* obj = [lectureArray objectAtIndex:row];
    
    UILabel *label1=(UILabel*)[cell viewWithTag:1];
    // UILabel *label2=(UILabel*)[cell viewWithTag:2]; 
    UILabel *label3=(UILabel*)[cell viewWithTag:3]; 
    
    UIImageView * imageview = (UIImageView*)[cell viewWithTag:4];
    
    label1.text = [obj.lectureName stringByAppendingFormat:@"(%@)",obj.teacherName];
    //label2.text = obj.lectureName;
    label3.text = obj.startTime;
    if (obj.isActive==YES) {
        imageview.image=[UIImage imageNamed:@"icon-on.png"];
    }
    else{
        imageview.image=[UIImage imageNamed:@"icon-over.png"];
    }
    return  cell;
    
}
- (void)dealloc {
    [tableView release];
    [tableView release];
    [tvCell release];
    [super dealloc];
}

-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    LectureInfoViewController* newinfoView = [[LectureInfoViewController alloc]initWithNibName:@"LectureInfoViewController" bundle:nil];
    newinfoView.Lectureinfo = [lectureArray objectAtIndex:[indexPath row]];
    [self.navigationController pushViewController:newinfoView animated:YES];
    [newinfoView release];
}

@end
