//
//  LectureListViewController.m
//  activelecture
//
//  Created by  on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LectureListViewController.h"
#import "NewLectureViewController.h"
#import "MainViewController.h"
#import "LectureDAO.h"
#import "Lecture.h"
#import "SBJson.h"
#import "ASIFormDataRequest.h"


@implementation LectureListViewController
@synthesize tvCell;
@synthesize tableView;
@synthesize lectureArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title=@"课程列表";
    addItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addAction:)];
    
    
    completeItem = [[UIBarButtonItem alloc] initWithTitle:@"完成" style:UIBarButtonItemStyleBordered target:self action:@selector(deleteAction:)];
    
    [self.navigationItem setLeftBarButtonItem: addItem animated:NO];
    
    
        
    UIImage *image = [UIImage imageNamed:@"title.png"];
    [addItem setTintColor:[UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1]];
    [completeItem setTintColor:[UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1]];        
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];    
    
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] init];
    barButtonItem.title = @"课程";
    barButtonItem.tintColor = [UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1];
    self.navigationItem.backBarButtonItem = barButtonItem;
    [barButtonItem release];

    //load data
    database = [[LectureDAO alloc]init];
    [database connect];
    
    lectureArray =[[NSMutableArray alloc]initWithArray: [database selectMetaData]];
    
    
    
   }

- (void)viewDidUnload
{
    [self setTableView:nil];
    [self setTvCell:nil];
    [database close];
    [self setLectureArray:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(void)addAction:(id)sender{
      
   NewLectureViewController *details = [[[NewLectureViewController alloc]initWithNibName:@"NewLectureViewController" bundle:nil]autorelease];
    [[Lecture sharedLecure]reset];
    [self.navigationController pushViewController:details animated:YES];
}

- (void)dealloc {
    [tableView release];
    [database release];
    [lectureArray release];
    [tvCell release];
    [super dealloc];
}
- (IBAction)deleteAction:(id)sender {
    [self.tableView setEditing:!self.tableView.editing animated:YES];

    if (self.tableView.editing) {
        [self.navigationItem setLeftBarButtonItem:completeItem animated:YES];
    }
    else{
        [self.navigationItem setLeftBarButtonItem:addItem animated:YES];
    }

}
-(void)refresh
{
    SBJsonWriter* writer = [[SBJsonWriter alloc]init];
    SBJsonParser* parser = [[SBJsonParser alloc]init];
    Lecture* sharedLecture = [Lecture sharedLecure];
    
    
    NSString *urlString=[sharedLecture.BASEURL stringByAppendingString:@"getSelectLectureInfo"];
    NSURL *url = [NSURL URLWithString:urlString];
    ASIFormDataRequest *request =[ASIFormDataRequest requestWithURL:url];
    NSMutableArray* ids=[NSMutableArray arrayWithCapacity:[lectureArray count]];
      
    for (Lecture* item in lectureArray) {
        [ids addObject:[NSString stringWithFormat:@"%d",item.classID]];
    }
    NSString* encodestr = [writer stringWithObject:ids];
    
    [request setPostValue:encodestr forKey:@"id"];
    
    
    [request setDelegate:self];
    [request setCompletionBlock:^{
        NSDictionary* datas = [parser objectWithString:[request responseString]];
        for (Lecture* item in lectureArray) {
            item.isActive =[[[datas objectForKey:[NSString stringWithFormat:@"%d",item.classID]] objectForKey:@"state"]boolValue];
        }
        [self.tableView reloadData];
        
    }];
    [parser release];
    [writer release];
    [request startAsynchronous];

}
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self refresh];
}


#pragma mark -
#pragma mark Table view
-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    int row = [indexPath row];
    MainViewController *details = [[[MainViewController alloc]initWithNibName:@"MainViewController" bundle:nil]autorelease];
    [[Lecture sharedLecure] setCurrentLecture:[lectureArray objectAtIndex:row]];
    [self.navigationController pushViewController:details animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [lectureArray count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableID=@"lectureListID";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:simpleTableID];
    
    if (cell == nil) {
        NSArray *nib=[[NSBundle mainBundle] loadNibNamed:@"lectureTableCell" owner:self options:nil];
        if ([nib count] > 0) {
            cell = self.tvCell;
        }
        else{
            NSLog(@"error");
        }
        
        
    }
    NSUInteger row=[indexPath row];
    Lecture* obj = [lectureArray objectAtIndex:row];
    
    UILabel *label1=(UILabel*)[cell viewWithTag:1];
    // UILabel *label2=(UILabel*)[cell viewWithTag:2]; 
    UILabel *label3=(UILabel*)[cell viewWithTag:3]; 
    
    UIImageView * imageview = (UIImageView*)[cell viewWithTag:4];
    
    label1.text = [obj.lectureName stringByAppendingFormat:@"(%@)",obj.teacherName];
    //label2.text = obj.lectureName;
    label3.text = obj.startTime;
    if (obj.isActive==YES) {
        imageview.image=[UIImage imageNamed:@"icon-on.png"];
    }
    else{
        imageview.image=[UIImage imageNamed:@"icon-over.png"];
    }
    return  cell;
    
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    NSUInteger row=[indexPath row];
    Lecture* obj = [lectureArray objectAtIndex:row];
    [database deleteItemByID:obj.classID];
    
    [lectureArray removeObjectAtIndex:row];
    [self.tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

@end
