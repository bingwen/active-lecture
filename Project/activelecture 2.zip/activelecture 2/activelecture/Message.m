//
//  Message.m
//  activelecture
//
//  Created by  on 12-6-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "Message.h"
#import "ASIFormDataRequest.h"
@implementation Message
@synthesize posterName=_posterName;
@synthesize text=_text;
static NSString* BASEURL= @"http://activelecture.sinaapp.com/ios/";
//static NSString* BASEURL= @"http://10.214.25.253/problem/index.php/ios/";
- (id)init {
    self = [super init];
    if (self) {
        self.posterName=@"匿名";
        self.text=@"";
    }
    return self;
}
-(void)dealloc{
    [self.text release];
    [self.posterName release];
    [super dealloc];
}
-(void)sendMessage:(int)classID{
    NSString *urlString=[BASEURL stringByAppendingString:@"postMessage/"];
    urlString=[urlString stringByAppendingString:[NSString stringWithFormat:@"%d",classID]];
    
    ASIFormDataRequest* form = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:urlString]];
    [form setPostValue:self.posterName forKey:@"name"];
    [form setPostValue:self.text forKey:@"content"];
    [form setFailedBlock:^{
        NSLog(@"fail");
    }];
    [form setCompletionBlock:^{
        NSLog(@"success");
    }];
    [form startAsynchronous];
    [form release];
}
@end
