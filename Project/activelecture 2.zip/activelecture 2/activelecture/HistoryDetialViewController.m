//
//  HistoryDetialViewController.m
//  activelecture
//
//  Created by  on 12-6-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "HistoryDetialViewController.h"
#import "History.h"
#import "HistoryDAO.h"
#import "OnePage.h"
@implementation HistoryDetialViewController

@synthesize pageViewController = _pageViewController;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"";
        // Custom initialization
    }
    return self;
}
- (id)initWithNibName:(NSString *)nibNameOrNil detailInfo:(History*) info
{
    self = [super initWithNibName:nibNameOrNil bundle:nil];
    if (self) {
        self.title=info.lectureName;
        infomation = [info retain];
        
        database = [[HistoryDAO alloc]init];
        // Custom initialization
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [database connect];
    detailHistories = [[database selectDetailHistoryByID:infomation.classID]retain];
   
    
   
    self.pageViewController = [[[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStylePageCurl navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal options:nil] autorelease];
    self.pageViewController.delegate = self;
    self.pageViewController.dataSource = self;
    
   
    OnePage *viewcontorller = [[[OnePage alloc ]initWithNibName:@"OnePage" bundle:nil]autorelease];
     viewcontorller.detailData = [detailHistories objectAtIndex:0];
   // OnePage *viewcontorller2 = [[[OnePage alloc ]initWithNibName:@"OnePage" bundle:nil]autorelease];
    NSArray *views = [NSArray arrayWithObjects:viewcontorller,nil];
    [self.pageViewController setViewControllers:views direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:NULL];
    
    
    [self addChildViewController:self.pageViewController];
    [self.view addSubview:self.pageViewController.view];
    
    CGRect pageViewRect = self.view.bounds;
    self.pageViewController.view.frame = pageViewRect;
    
    [self.pageViewController didMoveToParentViewController:self];    
    
    // Add the page view controller's gesture recognizers to the book view controller's view so that the gestures are started more easily.
    self.view.gestureRecognizers = self.pageViewController.gestureRecognizers;
    // Do any additional setup after loading the view from its nib.
    
    
}

- (void)viewDidUnload
{
    [database close];
  
    [self setPageViewController:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [infomation release];
    [database release];
    [_pageViewController release];
    [super dealloc];
}

- (UIPageViewControllerSpineLocation)pageViewController:(UIPageViewController *)pageViewController spineLocationForInterfaceOrientation:(UIInterfaceOrientation)orientation
{
    // Set the spine position to "min" and the page view controller's view controllers array to contain just one view controller. Setting the spine position to 'UIPageViewControllerSpineLocationMid' in landscape orientation sets the doubleSided property to YES, so set it to NO here.
    UIViewController *currentViewController = [self.pageViewController.viewControllers objectAtIndex:0];
    NSArray *viewControllers = [NSArray arrayWithObject:currentViewController];
    [self.pageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:NULL];
    
    self.pageViewController.doubleSided = NO;
    return UIPageViewControllerSpineLocationMin;
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    OnePage* page = (OnePage*)viewController;
    NSUInteger index = [detailHistories indexOfObject: page.detailData];

    index++;
    
    if (index < [detailHistories count]) {
        
        OnePage *nextpage = [[[OnePage alloc ]initWithNibName:@"OnePage" bundle:nil]autorelease];
         
        nextpage.detailData= [detailHistories objectAtIndex:index];
        return  nextpage;
    }
    else
        return  nil;
    
   
    
}

- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    OnePage* page = (OnePage*)viewController;
    NSInteger index = [detailHistories indexOfObject: page.detailData];
    
    index--;
    
    if (index >= 0) {
        
        OnePage *frontpage = [[[OnePage alloc ]initWithNibName:@"OnePage" bundle:nil]autorelease];
        
        frontpage.detailData= [detailHistories objectAtIndex:index];
        return  frontpage;
    }
    else
        return  nil;
}
@end
