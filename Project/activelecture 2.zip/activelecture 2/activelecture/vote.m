//
//  vote.m
//  activelecture
//
//  Created by  on 12-6-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "vote.h"
#import "ASIFormDataRequest.h"
@implementation Vote
@synthesize posterName=_posterName;
@synthesize choice=_choice;

static NSString* BASEURL= @"http://activelecture.sinaapp.com/ios/";
//static NSString* BASEURL= @"http://10.214.25.253/problem/index.php/ios/";
- (id)init {
    self = [super init];
    if (self) {
        self.posterName=@"匿名";
        self.choice=@"";
    }
    return self;
}
-(void)dealloc{
    [self.choice release];
    [self.posterName release];
    [super dealloc];
}
-(void)sendVote:(int)classID{
    NSString *urlString=[BASEURL stringByAppendingString:@"postVote/"];
    urlString=[urlString stringByAppendingString:[NSString stringWithFormat:@"%d",classID]];
    
    ASIFormDataRequest* form = [[ASIFormDataRequest alloc]initWithURL:[NSURL URLWithString:urlString]];
    [form setPostValue:self.posterName forKey:@"name"];
    [form setPostValue:self.choice forKey:@"choice"];
    [form setCompletionBlock:^{
       NSLog(@"vote success");
    }];
    [form setFailedBlock:^{
        NSLog(@"fail");
    }];
    [form startAsynchronous];
    [form release];
}

@end
