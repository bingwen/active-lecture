//
//  History.m
//  activelecture
//
//  Created by  on 12-6-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "History.h"

@implementation History
@synthesize lectureName=_lectureName;
@synthesize blackboard=_blackboard;
@synthesize date=_date;
@synthesize classID=_classId;
@synthesize note = _note;
-(void)dealloc{
    [_lectureName release];
    [_blackboard release];
    [_note release];
    [_date release];
}
+(History *)historyWithClassID:(int)classid LectureName:(NSString *)name BlackBoard:(NSString *)board Date:(NSString *)atime note:(NSString*) anote
{
    History* newone=[[History alloc]init];
    newone.classID=classid;
    newone.lectureName=name;
    newone.blackboard=board;
    newone.date=atime;
    newone.note=anote;
    return [newone autorelease];
}
@end
