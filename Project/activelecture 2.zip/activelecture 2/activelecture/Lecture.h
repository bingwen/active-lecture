//
//  Lecture.h
//  activelecture
//
//  Created by  on 12-6-27.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Lecture : NSObject
{
    int _classID;
    NSString* _lectureName;
    NSString* _teacherName;
    NSString* _introduction;
    NSString* _blackBoard;
    int _voteID;
    BOOL _isVoteValid;
    NSString* _startTime;
    NSString* _BASEURL; 
    BOOL _isActive;

    
}
@property(assign,atomic) int classID;
@property(copy,atomic) NSString* lectureName;
@property(copy,atomic)NSString* teacherName;
@property(copy,atomic)NSString* introduction;
@property(copy,atomic)NSString* blackBoard;
@property(assign,atomic)int voteID;
@property(assign,atomic)BOOL isVoteValid;
@property(assign,atomic)BOOL isActive;
@property(copy,atomic)NSString* startTime;
@property(readonly)NSString* BASEURL;
+(Lecture*)sharedLecure;
-(id)initWithClassID:(int)classID 
         LectureName:(NSString*)lectureName 
         TeacherName: (NSString*) teacherName
                Info:(NSString*) introduction
           StartTime:(NSString*) startTime;
-(void)reset;
-(void)setCurrentLecture:(Lecture*) lecture;
@end
