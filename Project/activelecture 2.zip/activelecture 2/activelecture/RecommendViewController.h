//
//  RecommendViewController.h
//  activelecture
//
//  Created by  on 12-7-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RecommendViewController : UIViewController
<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray* lectureArray;
    UITableViewCell* tvCell;
}
@property (retain, nonatomic) IBOutlet UITableView *tableView;
@property (retain, nonatomic) IBOutlet UITableViewCell *tvCell;

@end
