//
//  LectureListViewController.h
//  activelecture
//
//  Created by  on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LectureDAO;
@interface LectureListViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    UIBarButtonItem* addItem;
    UIBarButtonItem* completeItem;
    NSMutableArray* lectureArray;
    LectureDAO* database;
}
@property (retain, nonatomic) IBOutlet UITableView *tableView;
- (IBAction)deleteAction:(id)sender;
@property (retain, nonatomic) IBOutlet UITableViewCell *tvCell;
@property (retain, nonatomic)NSMutableArray* lectureArray;

@end
