//
//  NewLectureViewController.m
//  activelecture
//
//  Created by  on 12-7-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "NewLectureViewController.h"
#import "LectureListViewController.h"
#import "ASIHTTPRequest.h"
#import "SBJsonParser.h"
#import "Lecture.h"
#import "LectureDAO.h"
@implementation NewLectureViewController
@synthesize classIDTextField;
@synthesize dateLabel;
@synthesize introductionLabel;
@synthesize nameLabel;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"新课程";
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    //[self.navigationItem setHidesBackButton:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setClassIDTextField:nil];
    [self setDateLabel:nil];
    [self setIntroductionLabel:nil];
    [self setNameLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)addNewClick:(id)sender {
    if ([Lecture sharedLecure].classID!=0) {
    NSArray *allviewController = self.navigationController.viewControllers;
    [self.navigationController popViewControllerAnimated:YES];
        

    Lecture* newLecture = [Lecture sharedLecure];
    LectureListViewController* parent = [allviewController objectAtIndex:0];
    
        //update list if not in the lecture list
        BOOL flag = YES;
        for (Lecture* item in parent.lectureArray) 
        {
            if (item.classID==newLecture.classID){
                flag=NO;
                break;
            }
        }
        
        if (flag==YES) 
         [parent.lectureArray addObject:newLecture];
    
        [parent.tableView reloadData];
    
        //save to database
        LectureDAO* dao = [[LectureDAO alloc]init];
   
        [dao connect];
    
        [dao insert:newLecture];
        [dao close];    
        [dao release];
    }
    else
    {
        NSLog(@"failed");
    }
    
}
- (void)dealloc {
    [classIDTextField release];
    [dateLabel release];
    [introductionLabel release];
    [nameLabel release];
    [super dealloc];
}
- (IBAction)searchClassClick:(id)sender {
    if ([self.classIDTextField.text compare:@""]!= NO) {
        
        SBJsonParser* parser = [[SBJsonParser alloc]init];
        Lecture* sharedLecture = [Lecture sharedLecure];
        
        
        NSString *urlString=[sharedLecture.BASEURL stringByAppendingString:@"getLectureInfo/"];
        urlString=[urlString stringByAppendingString:classIDTextField.text];
        
        NSURL *url = [NSURL URLWithString:urlString];
        ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:url];
        [request setDelegate:self];
        [request setCompletionBlock:^{
            if ([[request responseString]compare:@"error"]!=0) {
                
            
            
            NSMutableDictionary* dic=[parser objectWithString:[request responseString]];
            //update mode
            if ([dic objectForKey:@"teacher_name"]) {
                 sharedLecture.teacherName=[dic objectForKey:@"teacher_name"];
            }
            else
            {
                sharedLecture.teacherName = @"匿名";
            }
            sharedLecture.classID= [[dic objectForKey:@"id"] intValue];
            sharedLecture.startTime=[dic objectForKey:@"apply_time"];          
            sharedLecture.lectureName = [dic objectForKey:@"name"];
            sharedLecture.introduction = [dic objectForKey:@"summary"];
            sharedLecture.isActive = [[dic objectForKey:@"state"]intValue];
            //update view
            nameLabel.text = [sharedLecture.teacherName stringByAppendingFormat:@" - %@",sharedLecture.lectureName];
            dateLabel.text = sharedLecture.startTime;
            introductionLabel.text = sharedLecture.introduction;            
            }
            else
            {
               
                UIAlertView* alert=[[[UIAlertView alloc]initWithTitle:@"Error" message:@"该ID不存在\n请输入正确的ID" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil]autorelease];
                [alert show];
                               
            }
            
        }];
        [request setFailedBlock:^{
            NSError *error = [request error];
            UIAlertView* alert=[[[UIAlertView alloc]initWithTitle:@"Error" message:@"该ID不存在\n请输入正确的ID" delegate:self cancelButtonTitle:@"cancel" otherButtonTitles:nil]autorelease];
            [alert show];
            
            NSLog(@"%@",error.description);
            
        }];
        [parser release];
        [request startAsynchronous];
        
       
    }
    else
    {
        UIAlertView* alert=[[[UIAlertView alloc]initWithTitle:@"提示" message:@"请输入课程ID" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil]autorelease];
        [alert show];
        
    }
}

- (IBAction)backgroundTap:(id)sender {
    [self.classIDTextField resignFirstResponder];
}
@end
