//
//  IntroductionViewController.m
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "IntroductionViewController.h"
#import "Lecture.h"

@implementation IntroductionViewController
@synthesize tableView;

@synthesize tvCell;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"关于";
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(responseForlogin) name:@"login" object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(responseForlogout) name:@"logout" object:nil];
   
    
   
        

    // Do any additional setup after loading the view from its nib.
}
-(void)responseForlogin{
    
 //   self.tabBarItem.enabled=YES;
}
-(void)responseForlogout{
    
   // self.tabBarItem.enabled = NO;
}
- (void)viewDidUnload
{
   
    [self setTableView:nil];
    [self setTvCell:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
   
  
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)dealloc {
    [tableView release];
    [tvCell release];
    [super dealloc];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
   
    return 3;
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    
    static NSString *simpleTableID=@"introductionID";
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier:simpleTableID];
    
    if (cell == nil) {
        NSArray *nib=[[NSBundle mainBundle] loadNibNamed:@"customCell" owner:self options:nil];
        if ([nib count] > 0) {
            cell = self.tvCell;
        }
        else{
            NSLog(@"error");
        }
        
                
    }
    NSUInteger row=[indexPath row];
    UILabel *label1=(UILabel*)[cell viewWithTag:1];
    UILabel *label2=(UILabel*)[cell viewWithTag:2];
    switch (row) {
        case 0:
            label1.text = @"版本";
            label2.text = @"version 0.1";
            
            break;
        case 1:
            label1.text = @"作者";
            label2.text = @"Donal";
            break;
        case 2:
            label1.text = @"Email";
            label2.text = @"zhouqzju@126.com";
            break;
        default:
            break;
    }
   
    
    //cell.imageView.image=[UIImage imageNamed:@"MessageEntrySendButton.png"];
    return cell;


}


@end
