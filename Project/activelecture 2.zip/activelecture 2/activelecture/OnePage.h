//
//  OnePage.h
//  activelecture
//
//  Created by  on 12-7-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "History.h"
@interface OnePage : UIViewController
{
    History* _detaildata;
}
@property (retain ,nonatomic) History* detailData;
@property (retain, nonatomic) IBOutlet UIView *fatherView;
@property (retain, nonatomic) IBOutlet UIView *boardView;
@property (retain, nonatomic) IBOutlet UIView *noteView;
@property (retain, nonatomic) IBOutlet UITextView *boardTextView;
@property (retain, nonatomic) IBOutlet UITextView *noteTextView;
@property (retain, nonatomic) IBOutlet UILabel *dateLabel;
- (IBAction)viewChange:(id)sender;
@end
