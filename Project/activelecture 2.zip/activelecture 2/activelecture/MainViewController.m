//
//  MainViewController.m
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "MainViewController.h"
#import "BoardViewController.h"
#import "ASIHTTPRequest.h"
#import "SBJson.h"
#import "Lecture.h"
#import "Message.h"
#import "vote.h"
#import "QuadCurveMenu.h"
#import "QuadCurveMenuItem.h"
@implementation MainViewController


@synthesize nameLabel;
@synthesize postField;
@synthesize nameInputField;


static NSString* BASEURL= @"http://activelecture.sinaapp.com/ios/";

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"Active Lecture";

      
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
   
    postFieldHeight = postField.frame.size.height;
    
    UIBarButtonItem* blackboard = [[UIBarButtonItem alloc]initWithTitle:@"小黑板" style:UIBarButtonItemStyleBordered  target:self action:@selector(showBlackBoard)];
    
    [blackboard setTintColor:[UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1]];
    
    [self.navigationItem setRightBarButtonItem:blackboard animated:YES];
    [blackboard release];
    
    UIBarButtonItem *barButtonItem = [[UIBarButtonItem alloc] init];
    barButtonItem.title = @"返回";
    barButtonItem.tintColor = [UIColor colorWithRed:143.0/255.0 green:70.0/255.0 blue:28.0/255.0 alpha:1];
    self.navigationItem.backBarButtonItem = barButtonItem;
    [barButtonItem release];
    
       //
    UIImage *storyMenuItemImage = [UIImage imageNamed:@"bg-menuitem.png"];
    UIImage *storyMenuItemImagePressed = [UIImage imageNamed:@"bg-menuitem-highlighted.png"];
    
        
    // vote view
    QuadCurveMenuItem *AItem = [[QuadCurveMenuItem alloc] initWithImage:storyMenuItemImage highlightedImage:storyMenuItemImagePressed 
                                                                    ContentImage:[UIImage imageNamed:@"A.png"] 
                                                         highlightedContentImage:nil];   
    // People MenuItem.
    QuadCurveMenuItem *BItem = [[QuadCurveMenuItem alloc] initWithImage:storyMenuItemImage highlightedImage:storyMenuItemImagePressed 
                                                                    ContentImage:[UIImage imageNamed:@"B.png"] 
                                                         highlightedContentImage:nil];    
    // Place MenuItem.
    QuadCurveMenuItem *CItem = [[QuadCurveMenuItem alloc] initWithImage:storyMenuItemImage highlightedImage:storyMenuItemImagePressed 
                                                                   ContentImage:[UIImage imageNamed:@"C.png"] 
                                                        highlightedContentImage:nil];    
    // Music MenuItem.
    QuadCurveMenuItem *DItem = [[QuadCurveMenuItem alloc] initWithImage:storyMenuItemImage highlightedImage:storyMenuItemImagePressed 
                                                                   ContentImage:[UIImage imageNamed:@"D.png"] 
                                                        highlightedContentImage:nil];    
    
    
    NSArray *menus = [NSArray arrayWithObjects:AItem, BItem, CItem, DItem, nil];
    [AItem release];
    [BItem release];
    [CItem release];
    [DItem release];
    
    
    QuadCurveMenu *menu = [[QuadCurveMenu alloc] initWithFrame:self.view.bounds menus:menus];
    [menu setCenter:CGPointMake(310, 310)];
    [self.view addSubview:menu];
    //[menu setExpanding:YES];
    menu.delegate = self;

    
    
    
    
    sharedLecture = [Lecture sharedLecure];
    
    [[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(keyboardWillShow:) 
                                                 name:UIKeyboardWillShowNotification 
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self 
                                             selector:@selector(keyboardWillHide:) 
                                                 name:UIKeyboardWillHideNotification 
                                               object:nil];	
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.nameLabel.text = [sharedLecture.teacherName stringByAppendingFormat:@" - %@",sharedLecture.lectureName];
    


}
//Code from Brett Schumann
-(void) keyboardWillShow:(NSNotification *)note{
    // get keyboard size and loctaion
	CGRect keyboardBounds;
    [[note.userInfo valueForKey:UIKeyboardFrameEndUserInfoKey] getValue: &keyboardBounds];
    NSNumber *duration = [note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSNumber *curve = [note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey];
    
    // Need to translate the bounds to account for rotation.
    keyboardBounds = [self.view convertRect:keyboardBounds toView:nil];
    
	// get a rect for the textView frame
	CGRect containerFrame = postField.frame;
    containerFrame.size.height =self.view.bounds.size.height - containerFrame.origin.y + self.tabBarController.tabBar.bounds.size.height -keyboardBounds.size.height -2;// animations settings
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:[duration doubleValue]];
    [UIView setAnimationCurve:[curve intValue]];
	
	// set views with new info
	postField.frame = containerFrame;
	
	// commit animations
	[UIView commitAnimations];
}

-(void) keyboardWillHide:(NSNotification *)note{
    NSNumber *duration = [note.userInfo objectForKey:UIKeyboardAnimationDurationUserInfoKey];
    NSNumber *curve = [note.userInfo objectForKey:UIKeyboardAnimationCurveUserInfoKey];
	
	// get a rect for the textView frame
	CGRect containerFrame = postField.frame;
    containerFrame.size.height = postFieldHeight;
	// animations settings
	[UIView beginAnimations:nil context:NULL];
	[UIView setAnimationBeginsFromCurrentState:YES];
    [UIView setAnimationDuration:[duration doubleValue]];
    [UIView setAnimationCurve:[curve intValue]];
    
	// set views with new info
	postField.frame = containerFrame;
	
	// commit animations
	[UIView commitAnimations];
}

- (void)quadCurveMenu:(QuadCurveMenu *)menu didSelectIndex:(NSInteger)idx
{
    [self chooseVote:idx];
    NSLog(@"Select the index : %d",idx);
}

- (void)viewDidUnload
{
    
    [self setPostField:nil];

    
 
    [self setNameInputField:nil];

    [self setNameLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}
//close keyboard

- (IBAction)backgroudtap:(id)sender {
    [postField resignFirstResponder];
   // [classIdInputFiled resignFirstResponder];
    [nameInputField resignFirstResponder];
}



- (IBAction)submitMessage:(id)sender {
    Message* mes=[[Message alloc]init];
    if ([self.nameInputField.text compare:@""]==NO) {
        mes.posterName=@"匿名";
    }
    else{
    mes.posterName = self.nameInputField.text;
    }
    mes.text = self.postField.text;
    
    [mes sendMessage:[sharedLecture classID]];
    [mes release];
                
}

- (void)chooseVote:(NSInteger)tag {
    Vote* vote=[[Vote alloc]init];
    
    
    vote.choice =[NSString stringWithFormat:@"%d",tag+1]; 
    [vote sendVote:[sharedLecture classID]];
    
    [vote release];
   
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [postField release];    
    [nameInputField release];   
    [nameLabel release];
    [super dealloc];
}

-(void)showBlackBoard{
    BoardViewController* details= [[BoardViewController alloc]initWithNibName:@"BoardViewController" bundle:nil];
    
    [self.navigationController pushViewController:details animated:YES];
    [details release];
}
/*-(void)textViewDidBeginEditing:(UITextView *)textView
{
   textView.text=@"";
}
*/

@end
