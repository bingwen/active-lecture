//
//  HistoryViewController.h
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HistoryDAO.h"
@interface HistoryViewController : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableArray *listData;
    HistoryDAO* HistoryDatabase;
}
@property (retain, nonatomic) IBOutlet UITableViewCell *tvCell;
@property (retain, nonatomic) IBOutlet UITableView *tableView;

@end
