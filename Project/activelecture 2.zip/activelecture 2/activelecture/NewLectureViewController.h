//
//  NewLectureViewController.h
//  activelecture
//
//  Created by  on 12-7-5.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewLectureViewController : UIViewController
- (IBAction)addNewClick:(id)sender;
@property (retain, nonatomic) IBOutlet UITextField *classIDTextField;
@property (retain, nonatomic) IBOutlet UILabel *dateLabel;
@property (retain, nonatomic) IBOutlet UITextView *introductionLabel;
@property (retain, nonatomic) IBOutlet UILabel *nameLabel;
- (IBAction)searchClassClick:(id)sender;
- (IBAction)backgroundTap:(id)sender;

@end
