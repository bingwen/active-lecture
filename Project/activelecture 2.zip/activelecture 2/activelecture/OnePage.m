//
//  OnePage.m
//  activelecture
//
//  Created by  on 12-7-6.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "OnePage.h"

@implementation OnePage
@synthesize noteTextView;
@synthesize dateLabel;
@synthesize fatherView;
@synthesize boardView;
@synthesize noteView;
@synthesize boardTextView;
@synthesize detailData = _detaildata;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.fatherView addSubview:noteView];
    [self.fatherView addSubview:boardView];
    
    self.boardTextView.text = self.detailData.blackboard;
    self.noteTextView.text = self.detailData.note;
   
    self.dateLabel.text = self.detailData.date;
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [self setFatherView:nil];
    [self setBoardView:nil];
    [self setNoteView:nil];
    [self setNoteTextView:nil];
    [self setBoardTextView:nil];
    [self setDateLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [fatherView release];
    [boardView release];
    [noteView release];
    [noteTextView release];
    [boardTextView release];
    [dateLabel release];
    [super dealloc];
}

- (IBAction)viewChange:(id)sender {
    [UIView beginAnimations:@"animationID" context:nil];
	[UIView setAnimationDuration:0.5f];
	[UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
	[UIView setAnimationRepeatAutoreverses:NO];
    
    
    [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromLeft forView:self.fatherView cache:YES];//oglFlip, fromLeft 
    [self.fatherView exchangeSubviewAtIndex:1 withSubviewAtIndex:0];
	[UIView commitAnimations];
}
@end
