//
//  database.h
//  activelecture
//
//  Created by  on 12-6-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <sqlite3.h>
#import "ASIProgressDelegate.h"
#import <Foundation/Foundation.h>
@class History;
@interface HistoryDAO : NSObject
{
    sqlite3* database;
}
-(BOOL)connect;
-(BOOL)insert:(id) item;
-(void)close;
-(NSArray*) selectMetaData;
-(NSArray*) selectDetailHistoryByID:(int)classID;
-(History*) selectDetailHistoryByID:(int)classID Date:(NSString*)date;
-(BOOL)deleteItemByID:(int) ID;
@end

