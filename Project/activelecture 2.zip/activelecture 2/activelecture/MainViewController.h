//
//  MainViewController.h
//  activelecture
//
//  Created by  on 12-6-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QuadCurveMenu.h"
@class SBJsonParser;
@class Lecture;
@interface MainViewController : UIViewController <QuadCurveMenuDelegate , UITextViewDelegate>
{
    SBJsonParser* parser;
    Lecture* sharedLecture;
    float postFieldHeight;
}

@property (retain, nonatomic) IBOutlet UILabel *nameLabel;

@property (retain, nonatomic) IBOutlet UITextView *postField;

@property (retain, nonatomic) IBOutlet UITextField *nameInputField;


- (IBAction)backgroudtap:(id)sender;
- (IBAction)submitMessage:(id)sender;



-(void)showBlackBoard;
- (void)chooseVote:(NSInteger)tag;
@end
