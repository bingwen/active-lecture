//
//  vote.h
//  activelecture
//
//  Created by  on 12-6-30.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Vote : NSObject
{
    NSString* _posterName;
    NSString* _choice;
    
    
}
@property(copy,nonatomic)NSString* posterName;
@property(copy,nonatomic)NSString* choice;
-(void)sendVote:(int)classID;
@end
