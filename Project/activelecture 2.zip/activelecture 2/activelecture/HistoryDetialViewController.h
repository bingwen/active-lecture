//
//  HistoryDetialViewController.h
//  activelecture
//
//  Created by  on 12-6-25.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class History;
@class HistoryDAO;
@interface HistoryDetialViewController : UIViewController
<UIPageViewControllerDataSource,UIPageViewControllerDelegate>
{
    History* infomation;
    HistoryDAO* database;
    UIPageViewController *_pageViewController;
    NSArray* detailHistories;
}

@property (retain, nonatomic) UIPageViewController *pageViewController;
- (id)initWithNibName:(NSString *)nibNameOrNil detailInfo:(History*) info;
@end
