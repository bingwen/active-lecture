//
//  LectureInfoViewController.m
//  activelecture
//
//  Created by  on 12-7-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "LectureInfoViewController.h"
#import "LectureListViewController.h"
#import "LectureDAO.h"

@implementation LectureInfoViewController
@synthesize nameLabel;
@synthesize dateLabel;
@synthesize classIDLabel;
@synthesize infoTextView;
@synthesize Lectureinfo = info;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"新课程";
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView
{
}
*/


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.classIDLabel.text = [NSString stringWithFormat:@"%d", self.Lectureinfo.classID ];
    self.nameLabel.text = [self.Lectureinfo.teacherName stringByAppendingFormat:@" - %@",self.Lectureinfo.lectureName];
    self.infoTextView.text = self.Lectureinfo.introduction ;
    self.dateLabel.text = self.Lectureinfo.startTime;
}


- (void)viewDidUnload
{
    [self setNameLabel:nil];
    [self setDateLabel:nil];
    [self setInfoTextView:nil];
    [self setClassIDLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [info release];
    [nameLabel release];
    [dateLabel release];
    [infoTextView release];
    [classIDLabel release];
    [super dealloc];
}
- (IBAction)addNew:(id)sender {
           
 //save to database              
    LectureDAO* dao = [[LectureDAO alloc]init];
    [dao connect];        
    [dao insert:self.Lectureinfo];
    [dao close];    
    [dao release];
    
//update lecture list
    
    UINavigationController* nav = [self.tabBarController.viewControllers objectAtIndex:0];
    LectureListViewController* list;
   
    list = [nav.viewControllers objectAtIndex:0];
    
    //update list if not in the lecture list
    BOOL flag = YES;
    for (Lecture* item in list.lectureArray) 
    {
        if (item.classID==self.Lectureinfo.classID){
            flag=NO;
            break;
        }
    }
    
    if (flag) 
        [list.lectureArray addObject:self.Lectureinfo];
    
    
    [list.tableView reloadData];
    
  
    UIAlertView* alert = [[UIAlertView alloc]initWithTitle:@"提示" message:@"添加成功" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:nil];
    [alert show];
    [alert release];
}
@end
