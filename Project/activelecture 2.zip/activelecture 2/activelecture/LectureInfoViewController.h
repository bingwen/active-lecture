//
//  LectureInfoViewController.h
//  activelecture
//
//  Created by  on 12-7-8.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Lecture.h"
@interface LectureInfoViewController : UIViewController
{
    Lecture* info;
}
@property (retain,nonatomic) Lecture* Lectureinfo;
@property (retain, nonatomic) IBOutlet UILabel *nameLabel;
@property (retain, nonatomic) IBOutlet UILabel *dateLabel;
@property (retain, nonatomic) IBOutlet UILabel *classIDLabel;
@property (retain, nonatomic) IBOutlet UITextView *infoTextView;
- (IBAction)addNew:(id)sender;

@end
