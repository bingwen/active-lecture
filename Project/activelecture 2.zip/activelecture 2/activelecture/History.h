//
//  History.h
//  activelecture
//
//  Created by  on 12-6-28.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface History : NSObject
{
    NSString* _lectureName;
    NSString* _blackboard;
    NSString* _date;
    NSString* _note;
    int _classId;

}
@property (copy,nonatomic) NSString* lectureName;
@property (copy,nonatomic) NSString* blackboard;
@property (copy,nonatomic) NSString* date;
@property (copy,nonatomic) NSString* note;
@property int classID;

+(History*)historyWithClassID:(int)classid LectureName:(NSString*)name BlackBoard:(NSString*)board Date:(NSString*)atime note:(NSString*) anote;
@end
