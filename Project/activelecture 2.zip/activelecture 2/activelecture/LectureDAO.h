//
//  LectureDAO.h
//  activelecture
//
//  Created by  on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//


#import <sqlite3.h>
#import "ASIProgressDelegate.h"
#import <Foundation/Foundation.h>
@interface LectureDAO : NSObject
{
    sqlite3* database;
}
-(BOOL)connect;
-(BOOL)insert:(id)item;
-(void)close;
-(NSArray*) selectMetaData;
-(NSString*) selectDetailLectureByID:(int)classID;
-(BOOL)deleteItemByID:(int) ID;
@end

