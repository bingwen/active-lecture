var jq=jQuery.noConflict();
var myurl="http://activelecture.sinaapp.com";
var lastTime = 0;
var allMessage = "";
$(function () {
	$("#editVote").click(function () {
		$("#saveVote").css('display', 'inline');
        $(".editChoice").css('display', 'inline');
        $(".voteChoice").css('display', 'none');
		$("#editVote").css('display', 'none');
		$("#vote h5").css('border-bottom', 'none');
		
		return true;
    });
	
	$("#saveVote").click(function () {
		saveVote();
		$("#saveVote").css('display', 'none');
        $(".editChoice").css('display', 'none');
        $(".voteChoice").css('display', 'inline');
		$("#editVote").css('display', 'inline');
		$("#vote h5").css('border-bottom', '1px solid #d1d1d1');		
		return true;
    });
});


jq(document).ready(function(){
  jq("#blackboard_submit").click(function(){
		var blackboard_content = jq("#blackboard_content").val();
		jq.post(myurl+"/Lecture/changeBlackboardContent/"+classID,{'content':blackboard_content},function(data){
			alert("Update Success !");
		},'json');
		return true;
  });
});
jq(document).ready(function(){
  jq("#clear_vote").click(function(){
		jq.post(myurl+"/Lecture/clearVoteData/"+classID,function(data){
			alert("Clear Success !");
		});
		return true;
  });
});

function getMessage()
{
	jq(document).ready(function(){	
		  jq.post(myurl+"/Lecture/getNewMessage/"+classID,{'lastTime':lastTime},function(data){
				lastTime = data.lastTime;
				dealWithMessage(data.list);
				dealWithVote(data.vote_result);
			},'json');
	});
}
function dealWithMessage(message)
{
	var newContent = "";
	for (item in message)
	{
		if(lastTime < message[item].post_time)
		{
			lastTime = message[item].post_time;
		}
		content = '<div class="item fl" id="message'+message[item].id+'"><div class="posterName">'+message[item].poster_name+' : <span class="delete fr"><img onClick="return deleteMessage(this)" name="'+message[item].id+'" src="/static/delete.png" /></span></div><div class="posterText">'+message[item].content+'</div></div>';
		 
		// allMessage = content+allMessage;
                 
                 newContent = content + newContent;
		
	}
	//jq("#container").html(allMessage);
        jq("#container").prepend(newContent);
        
        jq('#container').masonry( 'reload' );
      
	jq('#container').masonry({
  			itemSelector: '.item',
  			columnWidth: 100,
                        animate: true,

		});
}
function deleteMessage(pic)
{

	jq.post(myurl+"/Lecture/deleteMessage/"+classID+'/'+pic.name,function(data){
			if(data == "true")
			{
				ss = 'message'+pic.name;
				jq("#"+ss).remove();
                                /*
				jq('#container').masonry({
					itemSelector: '.item',
					columnWidth: 100
				});*/
                                jq('#container').masonry( 'reload' );
				alert("Delete Success !");
			}
			else
				alert("Delete error");
		});
		return true;
}

function dealWithVote(vote_result)
{
	jq("#voteQuestion").html(vote_result.question);
	jq("#voteAns1").html(vote_result.ans1);
	jq("#voteAns2").html(vote_result.ans2);
	jq("#voteAns3").html(vote_result.ans3);
	jq("#voteAns4").html(vote_result.ans4);
	
	//设置投票的数目  统计图
	//数字
	jq("#vote_bar1").html(vote_result.vote_num1);
	jq("#vote_bar2").html(vote_result.vote_num2);
	jq("#vote_bar3").html(vote_result.vote_num3);
	jq("#vote_bar4").html(vote_result.vote_num4);
	
	//bar长度
	
	max = parseInt(vote_result.vote_num1);
	max = max>parseInt(vote_result.vote_num2)?max:parseInt(vote_result.vote_num2);
	max = max>parseInt(vote_result.vote_num3)?max:parseInt(vote_result.vote_num3);
	max = max>parseInt(vote_result.vote_num4)?max:parseInt(vote_result.vote_num4);
	
	jq("#vote_bar1").height(vote_result.vote_num1*100/max+"px");
	jq("#vote_bar2").height(vote_result.vote_num2*100/max+"px");
	jq("#vote_bar3").height(vote_result.vote_num3*100/max+"px");
	jq("#vote_bar4").height(vote_result.vote_num4*100/max+"px");
	
}
function saveVote()
{
	jq(document).ready(function(){	
		  jq.post(myurl+"/Lecture/saveVote/"+classID,{'question':jq("#editQuestion").val(),'ans1':jq("#editAns1").val(),'ans2':jq("#editAns2").val(),'ans3':jq("#editAns3").val(),'ans4':jq("#editAns4").val()},function(data){
				if(data.result)
				{
					alert("Change Success !");
				}
				else
				{
					alert("Change Fail ! ");
				}
				getMessage();
			},'json');
	});
}

getMessage();
setInterval('getMessage()',5000);

