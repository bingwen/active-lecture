﻿$(function () {
	$("#editVote").click(function () {
		$("#saveVote").css('display', 'inline');
        $(".editChoice").css('display', 'inline');
        $(".voteChoice").css('display', 'none');
		$("#editVote").css('display', 'none');
		$("#vote h5").css('border-bottom', 'none');
		return true;
    });
	
	$("#saveVote").click(function () {
		$("#saveVote").css('display', 'none');
        $(".editChoice").css('display', 'none');
        $(".voteChoice").css('display', 'inline');
		$("#editVote").css('display', 'inline');
		$("#vote h5").css('border-bottom', '1px solid #d1d1d1');
		return true;
    });
	
	$("#addNew").click(function () {
		$("#exposeMask").css('display', 'block');
		$("#addClassDialog").css('display', 'block');
		return true;
	});
	$("#close").click(function () {
		$("#exposeMask").css('display', 'none');
		$("#addClassDialog").css('display', 'none');
		return true;
	});
});