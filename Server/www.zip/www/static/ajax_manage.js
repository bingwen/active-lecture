var jq=jQuery.noConflict();
var myurl="http://activelecture.sinaapp.com";

$(function () {
	$("#addNew").click(function () {
		$("#exposeMask").css('display', 'block');
		$("#addClassDialog").css('display', 'block');
		return true;
	});
	$("#close").click(function () {
		$("#exposeMask").css('display', 'none');
		$("#addClassDialog").css('display', 'none');
		return true;
	});

	$("#editVote").click(function () {
		$("#saveVote").css('display', 'inline');
        $(".editChoice").css('display', 'inline');
        $(".voteChoice").css('display', 'none');
		$("#editVote").css('display', 'none');
		$("#vote h5").css('border-bottom', 'none');
		
		return true;
    });
	
	$("#saveVote").click(function () {
		jq("#user_name").html(jq("#edit_user_name").val());
		jq("#user_email").html(jq("#edit_user_email").val());
		jq("#user_tip1").html(jq("#edit_user_tip1").val());
		jq("#user_tip2").html(jq("#edit_user_tip2").val());
	
	
		$("#saveVote").css('display', 'none');
        $(".editChoice").css('display', 'none');
        $(".voteChoice").css('display', 'inline');
		$("#editVote").css('display', 'inline');
		$("#vote h5").css('border-bottom', '1px solid #d1d1d1');
		saveUserInfo();
		return true;
    });
});

function saveUserInfo()
{
	jq(document).ready(function(){	
		  jq.post(myurl+"/Index/saveUserInfo/",{'user_name':jq("#edit_user_name").val(),'user_email':jq("#edit_user_email").val(),'user_tip1':jq("#edit_user_tip1").val(),'user_tip2':jq("#edit_user_tip2").val()},function(data){
				if(data.result)
				{
					alert("Change Success !");
				}
				else
				{
					alert("Change Fail ! ");
				}
			},'json');
	});
}