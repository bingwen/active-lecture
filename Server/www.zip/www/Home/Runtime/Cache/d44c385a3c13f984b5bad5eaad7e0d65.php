<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">

<head>
<meta http-equiv="X-UA-Compatible" content="IE=8" /><!--自动兼容IE8-->
<title>课程管理-<?php echo ($_SESSION['name']); ?></title><!--浏览器窗口标题-->

<!--引用CSS文件-->
<link rel="stylesheet" type="text/css" href="/static/layout.css" />

<!--引用JS文件-->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" ></script>
<script type="text/javascript" src="/static/jquery-1.7.1.min.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/jquery.masonry.min.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/ajax_manage.js" charset="utf-8"></script>

</head>

<body class="layout960">
	<div id="header"></div>
    <h3>课程管理<span class="fr"><a href="<?php echo U('Login/logout'); ?>">退出</a></span></h3>
	<div id="main" class="fl">
        
    	<!--课程列表-->
		<div id="container">
			<?php if(is_array($list)): foreach($list as $key=>$vo): ?><div class="item-class" id="<?php echo ($vo["id"]); ?>">
            	<div class="className"><?php echo ($vo["name"]); ?><span class="delete fr"><a href="<?php echo U('Index/deleteLecture'); ?>/<?php echo ($vo["id"]); ?>"><img src="/static/delete.png" /></a></span></div>
                <div class="classInfo">
				
				<?php if(($vo["state"] == 0)): ?><a href="<?php echo U('Lecture/index'); ?>/<?php echo ($vo["id"]); ?>"><div class="btn-pink fr">进入</div></a>
				<?php elseif($vo["state"] == 1): ?>
					<a href="<?php echo U('Index/startLecture'); ?>/<?php echo ($vo["id"]); ?>"><div class="btn-blue fr">开始</div></a>
				<?php else: ?> 
					<a href="<?php echo U('Lecture/history'); ?>/<?php echo ($vo["id"]); ?>"><div class="btn-green fr">查看</div></a><?php endif; ?>

                	<p>时间：<b><span name="classStart"><?php echo ($vo["start_time"]); ?></span></b></p>
                    <p>时长：<span name="classDuration"><?php echo ($vo["duration"]); ?>分钟</span></p>
                </div>
            </div><?php endforeach; endif; ?>
		</div>
    	<!-- container 课程列表 ends -->
    </div>
    <!-- main end-->
    
    <!--侧边栏-->
    <div id="aside" class="box-shadow fr">
    	<div id="addNew">
            <div class="btn-pink">添加课程</div>
        </div>
    	<div id="vote">
        	<h4>个人信息<span id="editVote" class="fr">编辑</span>
			<span id="saveVote" class="fr">保存</span></h4>
        	<br />
            <p><b>主讲人</b>：<span id="user_name" class="voteChoice"><?php echo ($_SESSION['name']); ?></span>
			<span class="editChoice"><br /><input type="text" id="edit_user_name" name="instructor" /></span></p>
			
            <p><b>邮箱</b>：<span id="user_email" class="voteChoice"><?php echo ($userDetail['email']); ?></span>
			<span class="editChoice"><br /><input type="text" id="edit_user_email" name="email" /></span></p>
			
            <p><span id="user_tip1" class="voteChoice"><?php echo ($userDetail['tip1']); ?></span>
			<span class="editChoice"><b>自定义1</b><br /><textarea id="edit_user_tip1" name="custom1"></textarea></span></p>
			
            <p><span id="user_tip2" class="voteChoice"><?php echo ($userDetail['tip2']); ?></span>
			<span class="editChoice"><b>自定义2</b><br/><textarea id="edit_user_tip2" name="custom2"></textarea></span></p>
        </div>
        <div id="board">
        	<h4>使用帮助</h4>
            <p>呵呵呵呵</p>
        </div>
    </div>
    <!-- 侧边栏 end -->
    <div class="clear"></div>
    
    <!-- 页脚 -->
    <div id="footer">
    	<p>Active Lecture @ ZJU</p>
    </div>
    
    <div id="toTop" onclick="window.scrollTo(0,0);return false;">
    </div>
    
    <div id="addClassDialog">
    	<div class="hd">
            <h5>添加课程</h5>
        </div>
        <div class="bd">
            <form id="addClass-form" action=<?php echo U('Index/addLecture'); ?>    method="post">
				<p><input type="text" id="className" name="className" placeholder="请输入课程名称" /></p>
                <p><input type="text" id="classStartTime" name="classStartTime" placeholder="请输入开始时间" /></p>
                <p><input type="text" id="classDuration" name="classDuration" placeholder="请输入时长" /></p>
                <input type="submit" class="btn-pink" value="添加" />
            </form>
        </div>
		<span id="close"></span>
    </div>
    
    <div id="exposeMask"></div>
    
</body>

</html>