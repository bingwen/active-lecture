<?php if (!defined('THINK_PATH')) exit();?>﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en">

<head>
<meta http-equiv="X-UA-Compatible" content="IE=8" /><!--自动兼容IE8-->
<title>软件工程-<?php echo ($_SESSION['name']); ?></title><!--浏览器窗口标题-->

<!--引用CSS文件-->
<link rel="stylesheet" type="text/css" href="/static/layout.css" />
<link rel="stylesheet" type="text/css" href="/static/vote_graph.css" />
<!--引用JS文件-->
<script type="text/javascript"> var classID = <?php echo ($classDetail['id']); ?>;</script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js" ></script>
<script type="text/javascript" src="/static/jquery-1.7.1.min.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/jquery.masonry.min.js" charset="utf-8"></script>
<script type="text/javascript" src="/static/ajax.js" charset="utf-8"></script>

</head>

<body class="layout960">
	<div id="header"></div>
    <h3><?php echo ($classDetail['name']); ?><span class="fr">
	<a href="<?php echo U('Index/index'); ?>">课程管理</a></span></h3>
	<div id="main" class="fl">
        <!--
        <div id="loadNewPoster">有9条新消息，点击查看</div>
        -->
    	<!--问题墙瀑布流-->
		<div id="container">
            
		</div>
    	<!-- container 瀑布流 ends -->
    </div>
    <!-- main end-->
    
    <!-- 应用瀑布流插件重新排列 -->
    <script type="text/javascript" charset="utf-8">
		$('#container').masonry({
  			itemSelector: '.item',
  			columnWidth: 100
		});
    </script>
    
    <!--侧边栏-->
    <div id="aside" class="box-shadow fr">
    	<div id="vote">
        	<h4>投票<span id="editVote" class="fr">编辑</span><span id="saveVote" class="fr">保存</span></h4>
        	<h5>
            	<span id="voteQuestion" class="voteChoice">这是投票信息栏，请点击编辑.</span>
            	<span class="editChoice"><textarea id="editQuestion">请输入题目</textarea></span>
            </h5>
            <p><b>A)</b><span id="voteAns1" class="voteChoice">这是第一个选项，请点击右上角编辑该选项.</span>
			<span class="editChoice">&nbsp;<input type="text" id="editAns1" name="choice-a" /></span></p>
			
            <p><b>B)</b><span id="voteAns2" class="voteChoice">这是第二个选项，请点击右上角编辑该选项.</span>
			<span class="editChoice">&nbsp;<input type="text" id="editAns2" name="choice-b" /></span></p>
			
            <p><b>C)</b><span id="voteAns3" class="voteChoice">这是第三个选项，请点击右上角编辑该选项.</span>
			<span class="editChoice">&nbsp;<input type="text" id="editAns3" name="choice-c" /></span></p>
			
            <p><b>D)</b><span id="voteAns4" class="voteChoice">这是第四个选项，请点击右上角编辑该选项.</span>
			<span class="editChoice">&nbsp;<input type="text" id="editAns4" name="choice-d" /></span></p>
            
            <br />（统计图）
			<!--
            <img src="/static/stat.png" height=30 />
			-->
			<div class="vote_graph">
			<ul id="q-graph"> 
				<li id="q1" class="qtr"> A 
					<ul>  
						<li class="north bar" style="height:55px;">18</li> 
						<li class="south bar" style="height:50px;">16</li> 
					</ul>
				</li> 

				<li id="q2" class="qtr"> B 
					<ul>  
						<li class="north bar" style="height:99px;">32</li>  
						<li class="south bar" style="height:105px;">34</li> 
					</ul>
				</li> 

				<li id="q3" class="qtr"> C 
					<ul>  
						<li class="north bar" style="height:130px;">43</li>  
						<li class="south bar" style="height:99px;">32</li> 
					</ul>
				</li> 

				<li id="q4" class="qtr"> D 
					<ul>  
						<li class="north bar" style="height:55px;">18</li>  
						<li class="south bar" style="height:99px;">32</li> 
					</ul>
				</li>  

				<li id="ticks"> 
					<div class="ticks"><p>50</p></div> 
					<div class="ticks"><p>40</p></div> 
					<div class="ticks"><p>30</p></div> 
					<div class="ticks"><p>20</p></div> 
					<div class="ticks"><p>10</p></div>
				</li>
			</ul>
			</div>
            <div id="clear_vote" class="btn-pink">清空计数</div>
        </div>
    	<div id="board">
        	<h4>小黑板</h4>
        	<textarea id="blackboard_content"><?php echo ($classDetail['blackboard']); ?></textarea>
        	<div id="blackboard_submit" class="btn-pink" >更新</div>
        </div>
    </div>
    <!-- 侧边栏 end -->
    <div class="clear"></div>
    
    <!-- 页脚 -->
    <div id="footer">
    	<p>Active Lecture @ ZJU</p>
    </div>
    
    <div id="toTop" onclick="window.scrollTo(0,0);return false;">
    </div>
    
    
</body>

</html>