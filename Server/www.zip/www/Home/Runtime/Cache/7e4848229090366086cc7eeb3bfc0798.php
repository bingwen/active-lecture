<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>OOO</title>
	<meta content="text/html; charset=utf-8" http-equiv="content-type" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
	<meta name="author" content="Steven" />
	<link href='http://fonts.googleapis.com/css?family=Electrolize' rel='stylesheet' type='text/css' />
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.0/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="/Public/css/header.css" />

</head>
<body>

<div id="header">
			<ul id="navigation">
				<li><a id="link-news" href="<?php echo U('Index/index') ?>">首页</a></li>
				<li><a id="link-home" href="<?php echo U('Login/index') ?>">
				<?php if(session('?name')) echo session('name').' 已登录'; else echo '登录'; ?>
				</a></li>
				<li><a id="link-home" href="<?php echo U('Login/logout') ?>">登出</a></li>
			</ul>
</div>
<hr >
<div id="content">

	
	This is index page!
	<form action='addClass' method='POST'>
	ClassName<input type='text' id='user_name' name='user_name'/><br>
	StartTime<input type='text' id='start_time' name='start_time'/><br>
	Duration<input type='text' id='duration' name='duration'/><br>
	BlackBoard<input type='text' id='blackboard'  name='blackboard'/><br>
	<input type='submit' value='提交' id='submit' name='submit'/>
	</form>
	
<?php if(is_array($list)): foreach($list as $key=>$vo): ?><div>
<?php echo ($vo["id"]); ?>
<?php echo ($vo["name"]); ?>
<?php echo ($vo["start_time"]); ?>
<?php echo ($vo["duration"]); ?>
<?php echo ($vo["state"]); ?>
<?php echo ($vo["blackboard"]); ?>
<?php echo ($vote_num); ?>
<a href='deleteClass/<?php echo ($vo["id"]); ?>'>删除该课程</a>
</div><?php endforeach; endif; ?>


	

</div><!--content-->
<hr noshade>
<div id="footer">
Powered by <a href='http://www.weibo.com/bingwenshi' target='blank'>Steven</a>
</div>
</body>
</html>