<?php
return array(
	//'配置项'=>'配置值'
	'URL_CASE_INSENSITIVE' =>true,

	//配置数据库
	'DB_DSN'=>'mysql://username:password@localhost:3306/DBName',
	'DB_PREFIX'=>'',
);
?>