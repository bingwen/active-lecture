<?php
class LoginAction extends Action{

	public function index(){
		//检查用户是否登录
		if(session('name'))  
		//跳转到首页
			redirect(U('Index/index'));
		else{
		//跳转到登录页面
			redirect(U('Login/login'));
		}
	}
	public function login(){
		$this->display("login");
	}
	public function login_submit(){
		  //判断有无参数
		if(!isset($_POST['email']))
			//展示本页面
			$this->login();
		else
		{
			//获取参数
			$user['email']=$_POST['email'];
			$user['password'] = $_POST['password'];
		 
			if($id=$this->check_login($user))
			{
				$userTable = M('User');
				$map['id']=$id;
				$result = $userTable->where($map)->find();
				
				session('name',$result['name']);
				session('userID',$id);
				redirect(U('Index/index'));
			}
			else
			{
				$this->error('登录失败，请检查用户名和密码！',U('Login/login'));
			}
		}
	}
	public function check_login($user){
		$userTable = M('User');
		$map['email']=$user['email'];
		$result = $userTable->where($map)->select();
		if($result==null)
		{
			return false;
		}
		else if($result[0]['password'] == md5($user['password']))
			return $result[0]['id'];
		else
		{
			return false;
		}
	}
	public function logout(){
		session(null);
		redirect(U('Login/login'));
	}
	
	public function register()
	{
		$this->display('register');
	}
	
	public function register_submit(){
		  //判断有无参数
		if(!isset($_POST['email'])||($_POST['password1']!==$_POST['password2']))
			//展示本页面
			$this->register();
		else
		{
			//获取参数
			$user['name']=$_POST['name'];
			$user['email']=$_POST['email'];
			$user['password'] = md5($_POST['password1']);
			$user['teacher'] = 1;
			$user['class_count'] = 0;
		 
			if($id=$this->check_register($user))
			{
				$userTable = M('User');
				$result = $userTable->data($user)->add();
				$result2 = $userTable->where($user)->find();
				
				if($result2)
				{
					$userinfo = M('Userinfo');
					$data2['user_id'] = $result2['id'];
					$data2['email'] = $result2['email'];
					$data2['weibo'] = "http://weibo.com/";
					$data2['tip1'] = "这是第一条tip";
					$data2['tip2'] = "这是第二条tip";
					$result3 = $userinfo->data($data2)->add();
					
					session('name',$result2['name']);
					session('userID',$result2['id']);
					redirect(U('Index/index'));
				}
				else
				{
					$this->error('注册失败，数据添加失败！',U('Login/register'));
				}
			}
			else
			{
				$this->error('注册失败，该用户可能已存在或者邮件地址不正确！',U('Login/register'));
			}
		}
	}
	
	public function check_register($user){
		if(!$this->is_valid_email($user['email']))
			return false;
			
		$userTable = M('User');
		$map['email']=$user['email'];
		$result = $userTable->where($map)->select();
		if($result==null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	function is_valid_email($email, $test_mx = false)
	{
		if(eregi("^([_a-z0-9-]+)(.[_a-z0-9-]+)*@([a-z0-9-]+)(.[a-z0-9-]+)*(.[a-z]{2,4})$", $email))
		{
			if($test_mx)
			{
				list($username, $domain) = split("@", $email);
				return getmxrr($domain, $mxrecords);
			}
			else
				return true;
		}
		else
			return false;
	}
}