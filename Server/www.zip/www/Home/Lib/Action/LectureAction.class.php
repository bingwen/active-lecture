<?php
// 首页
class LectureAction extends Action {
//构造函数，验证Session
	public function __construct() 
	{
	    parent::__construct(); //一定要注意这一行，这一行是为了执行父类中的构造函数，否则运行是会出错的
	    $this->CheckSession();//
	}
	 
	private function CheckSession()
	{
	        if(!session('userID')){
	            //$this->error('未登录或登录超时，请重新登录',U('Login/login'));
				redirect(U('Login/login'));
	    }
	}
	
    public function index()
	{
		$classID = $_GET['_URL_'][2];
		$class = M('Class');
		$result = $class->where('id='.$classID)->find();
		
		$this->assign('classDetail',$result);

		$this->display('AC:inLecture');
		
    }
	public function getBlackboardContent()
	{
		$classID = $_GET['_URL_'][2];
		$class = M('Class');
		$result = $class->where('id='.$classID)->find();
		echo json_encode(array('blackBoardContent'=>$result['blackboard']));
		
    }
	public function changeBlackboardContent()
	{
		$classID = $_GET['_URL_'][2];
		$content = $_POST['content'];
		$class = M('Class');
		$data['blackboard'] = $content;
		$result = $class->where('id='.$classID)->save($data);
		$return_data['content'] = $content;
		if($result)
		{
			echo json_encode($return_data);
		}
		else
		{
			echo false;
		}
		
    }
	public function getNewMessage()
	{
		$classID = $_GET['_URL_'][2];
		$lasttime = $_POST['lastTime'];
		$message = M('Message');
		$map['class_id']=array('eq',$classID);
		$map['post_time']=array('gt',$lasttime);
		$list = $message->where($map)->select();
		$lasttime = date('Y-m-d H:i:s');
		
		$vote = M('Vote');
		$vote_result = $vote->where('class_id='.$classID)->find();
		
		echo json_encode(array('list'=>$list,'lastTime'=>$lasttime,'vote_result'=>$vote_result));
		
    }
    public function deleteMessage()
	{
		$classID = $_GET['_URL_'][2];
		$id = $_GET['_URL_'][3];
		$message = M('Message');
		$result=$message->where('id='.$id.' and class_id='.$classID)->delete();

		if($result)
		{
			echo 'true';
		}
		else
		{
			echo 'false';
		}
	}
	public function getVoteNum()
	{
		$classID = $_GET['_URL_'][2];
		$vote = M('Vote');
		$result = $vote->where('class_id='.$classID)->find();
	}
	public function saveVote()
	{
		$classID = $_GET['_URL_'][2];
		
		$data['question'] = $_POST['question'];
		$data['ans1'] = $_POST['ans1'];
		$data['ans2'] = $_POST['ans2'];
		$data['ans3'] = $_POST['ans3'];
		$data['ans4'] = $_POST['ans4'];
		
		$vote = M('Vote');
		$result = $vote->where('class_id='.$classID)->data($data)->save();
		$result = $data['question'];
		echo json_encode(array('result'=>$result));
	}
	public function clearVoteData()
	{
		$classID = $_GET['_URL_'][2];

		$vote = M('Vote');
		$result = $vote->where('class_id='.$classID)->find();
		$data['vote_num1']=0;
		$data['vote_num2']=0;
		$data['vote_num3']=0;
		$data['vote_num4']=0;
		$data['state']=rand();
		while($data['state'] == $result['state'])
		{
			$data['state']=rand();
		}
		$list = $vote->where('class_id='.$classID)->data($data)->save();
		if($list)
		{
			echo true;
		}
		else{
			echo false;
		}
    }


}
