<?php

class IosAction extends Action {

	public function __construct() 
	{
	    parent::__construct(); //一定要注意这一行，这一行是为了执行父类中的构造函数，否则运行是会出错的

	}
	 
	
    public function index()
	{	
		
    }
	
	public function getBlackBoard()
	{
		$classID = $_GET['_URL_'][2];
		$class = M('Class');
		$result = $class->where('id='.$classID)->find();
		echo json_encode(array("blackboard"=>$result['blackboard']));
	}
	public function getSuggest()
	{
		$class = M('Class');
		$result = $class->order("apply_time desc")->limit(5)->page(1)->select();
		$user = M('User');
		foreach($result as &$item)
		{
			$result2 = $user->where('id='.$item['user_id'])->find();
			$item['teacher_name'] = $result2['name'];
		}
		
		echo json_encode($result);
	}
	public function getLectureInfo(){
		$classID = $_GET['_URL_'][2];
		$class = M('Class');
		$result = $class->where('id='.$classID)->find();
                if(!$result)
                {
                	echo "error";
                        exit();
                }
		$user = M('User');
		$result2 = $user->where('id='.$result['user_id'])->find();
		$result['teacher_name'] = $result2['name'];
		
		echo json_encode($result);
	}
	public function getSelectLectureInfo(){
	
		$classIDS = json_decode($_POST['id']);
                
		$class = M('Class');
		$user = M('User');
		foreach($classIDS as $classID)
		{	
			$result = $class->where('id='.$classID)->find();		
			//$result2 = $user->where('id='.$result['user_id'])->find();
			//$result['teacher_name'] = $result2['name'];
			$data[$classID] = $result;
			$result = null;
		}
		echo json_encode($data);
	}
	
	public function postMessage()
	{
		$classID = $_GET['_URL_'][2];
		$data['class_id'] = $classID;
		if($_POST['name'])
		{
			$data['poster_name'] = $_POST['name'];
		}
		if($_POST['content'])
		{
			$data['content'] = $_POST['content'];
		}
		$message = M('Message');
		$result = $message->data($data)->add();
		if($result)
		{
			echo 'true';
		}
		else
		{
			echo 'false'.json_encode($data);
		}
	}
	public function postVote()
	{
		$classID = $_GET['_URL_'][2];
		if($_POST['name'])
		{
			$poster_name = $_POST['name'];
		}
		if($_POST['choice'])
		{
			$choice = $_POST['choice'];
		}
		$vote = M('Vote');
		
		switch($choice)
		{
			case '1':
				$data = $vote->where('class_id='.$classID)->find();
				$data['vote_num1'] = $data['vote_num1'] + 1;
				$result = $vote->where('class_id='.$classID)->data($data)->save();
				break;
			case '2':
				$data = $vote->where('class_id='.$classID)->find();
				$data['vote_num2'] = $data['vote_num2'] + 1;
				$result = $vote->where('class_id='.$classID)->data($data)->save();
				break;
			case '3':
				$data = $vote->where('class_id='.$classID)->find();
				$data['vote_num3'] = $data['vote_num3'] + 1;
				$result = $vote->where('class_id='.$classID)->data($data)->save();
				break;
			case '4':
				$data = $vote->where('class_id='.$classID)->find();
				$data['vote_num4'] = $data['vote_num4'] + 1;
				$result = $vote->where('class_id='.$classID)->data($data)->save();
				break;	
			default:
				echo 'false'; exit();
				break;
		}
		
		echo 'true';
	}
	public function getVote()
	{
		$classID = $_GET['_URL_'][2];
		$vote = M('Vote');
		$result = $vote->where('class_id='.$classID)->find();
		echo json_encode($result);
	}
}
