<?php
// 首页
class IndexAction extends Action {
//构造函数，验证Session
	public function __construct() 
	{
	    parent::__construct(); //一定要注意这一行，这一行是为了执行父类中的构造函数，否则运行是会出错的
	    $this->CheckSession();//
	}
	 
	private function CheckSession()
	{
	        if(!session('userID')){
				redirect(U('Login/login'));
			}
	}
	
    public function index()
	{
	
		$page_num = 1;
		$class = M('Class');
		$list = $class->where('user_id='.$_SESSION['userID'])->order('apply_time desc')->Page($page_num.',20')->select();
		
		$this->assign('list',$list);
		$this->assign('page_num',$page_num);
		
		$userinfo = M('userinfo');
		
		$userDetail = $userinfo->where('user_id='.$_SESSION['userID'])->find();
		$this->assign('userDetail',$userDetail);
		
		
        $this->display('AC:manage');
    }
	/*
	 public function page()
	{
		$page_num = $_GET['_URL_'][2];
		$class = M('Class');
		$list = $class->where('user_id='.$_SESSION['userID'])->order('apply_time')->Page($page_num.',20')->select();
		
		$this->assign('list',$list);
		$this->assign('page_num',$page_num);
		
		$userinfo = M('userinfo');
		
		$userDetail = $userinfo->where('user_id='.$_SESSION['userID'])->find();
		$this->assign('userDetail',$userDetail);
		
		
        $this->display('AC:manage');
    }
	*/
	public function startLecture(){
		$id = $_GET['_URL_'][2];
		$class = M('Class');
		$data['state'] = 1;
		$result = $class->where('id='.$id)->data($data)->save();
		
		redirect(U('Lecture/index').'/'.$id);
	}
	public function addLecture(){
		$class = M('Class');
		
		$data['id'] = $this->idGenerate();
		$data['name'] = $_POST['className'];
		
		//$data['apply_time'] = date('Y-m-d H:i:s');
		$data['start_time'] = $_POST['classStartTime'];
		$data['duration'] = $_POST['classDuration'];
		$data['summary'] = $_POST['classSummary'];
		$data['state'] = 0;
		$data['user_id'] = $_SESSION['userID'];
		
		if($_POST['blackboard'])
		{
			$data['blackboard'] = $_POST['blackboard'];
		}
		else
		{
			$data['blackboard'] = "这是小黑板！";
		}
		if($data['vote_num'])
		{
			$data['vote_num'] = $_POST['voteNum'];
		}
		else
		{
			$data['vote_num'] = 4;
		}
		$result = $class->data($data)->add();
			
		if($result)
		{
			$vote = M('Vote');
			$data2['class_id'] = $data['id'];
			$data2['state'] = 1;
			$data2['question'] = '这是投票信息栏，请点击编辑.';
			$data2['ans1'] = '这是第一个选项，请点击右上角编辑该选项.';
			$data2['ans2'] = '这是第二个选项，请点击右上角编辑该选项.';
			$data2['ans3'] = '这是第三个选项，请点击右上角编辑该选项.';
			$data2['ans4'] = '这是第四个选项，请点击右上角编辑该选项.';
			$result2 = $vote->data($data2)->add();
			
			redirect(U('Index/index'));
		}
		else
		{
			//$this->error('课程添加出错',U('Index/index'));
			echo json_encode($data);
		}

	}
	public function deleteLecture()
	{
		$id = $_GET['_URL_'][2];
		$class = M('Class');
		$result=$class->where('id='.$id.' and user_id='.session('userID'))->delete();
		$vote = M('Vote');
		$message = M('Message');
		if($result)
		{
			$result2=$vote->where('class_id='.$id)->delete();
			$result3=$message->where('class_id='.$id)->delete();
			redirect(U('Index/index'));
		}
		else
		{
			$this->error('课程删除出错'.$id.'  '.session('userID'),U('Index/index'));
		}
	}
	public function idGenerate(){
		$user = M('User');
		
		$result = $user->where('id='.session('userID'))->find();
		if($result){
			$id = session('userID')*10000+$result['class_count']+1;
		}
		else{
			$this->error('课程ID生成出错',U('Index/index'));
		}
		$class = M('Class');
		while($result = $class->where('id='.$id)->find())
		{
			$id = $id+1;
		}
		return $id;
	}
	public function saveUserInfo()
	{	
		$data['name'] = $_POST['user_name'];
		$data['email'] = $_POST['user_email'];
		$user = M('User');
		$result1 = $user->where('id='.$_SESSION['userID'])->data($data)->save();
		session('name',$_POST['user_name']);
				
		$data['weibo'] = $_POST['user_weibo'];
		$data['tip1'] = $_POST['user_tip1'];
		$data['tp2'] = $_POST['user_tip2'];
		$userinfo = M('Userinfo');
		$result12 = $userinfo->where('user_id='.$_SESSION['userID'])->data($data)->save();
		
		
		echo json_encode(array('result'=>true));
	}

}
