<?php
	header("Content-Type:text/html;charset=utf-8");
	define('APP_PATH','./Home/');
	require("./ThinkPHP/Extend/Engine/Sae.php");
?>